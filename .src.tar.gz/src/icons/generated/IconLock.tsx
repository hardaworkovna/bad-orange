"use client";
import type { SVGProps } from "react";
import { useId } from "react";

/** Figma: Design system → Icons → "lock" (18.3317×22.8075) */
export function IconLock({ size, width, height, ...props }: SVGProps<SVGSVGElement> & { size?: number | string }) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "") + "-";
  return (
    <svg
      viewBox="0 0 18.3317 22.8075"
      width={width ?? size ?? 18.3317}
      height={height ?? size ?? 22.8075}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      focusable="false"
      {...props}
    >
      <g id={`${uid}Group`}>
        <path
          id={`${uid}Vector`}
          d="M17.4208 9.72675C16.8334 9.1395 16.0524 8.81625 15.222 8.81625H14.997V5.7255C14.997 2.56837 12.4286 0 9.27169 0H9.06C5.90306 0 3.3345 2.56837 3.3345 5.7255V8.81606H3.1095C2.27906 8.81606 1.49812 9.1395 0.910687 9.72675C0.323437 10.3142 0 11.0951 0 11.9257V19.698C0 20.5286 0.323437 21.3096 0.910687 21.8966C1.49794 22.4841 2.27888 22.8075 3.1095 22.8075H15.222C16.0526 22.8075 16.8336 22.4841 17.421 21.8966C18.0083 21.3094 18.3317 20.5284 18.3317 19.698V11.9257C18.3317 11.0953 18.0083 10.3144 17.4208 9.72675ZM4.8345 5.7255C4.8345 3.39562 6.72994 1.5 9.06 1.5H9.27169C11.6016 1.5 13.497 3.39562 13.497 5.7255V8.81606H4.8345V5.7255ZM16.8317 19.698C16.8317 20.1216 16.6598 20.5363 16.3603 20.8359C16.0562 21.1401 15.6519 21.3075 15.222 21.3075H3.1095C2.67956 21.3075 2.2755 21.1401 1.97119 20.8357C1.66725 20.532 1.49981 20.1279 1.49981 19.698V11.9257C1.49981 11.4958 1.66725 11.0914 1.97119 10.7874C2.27531 10.4835 2.67938 10.3161 3.10931 10.3161H15.2218C15.6518 10.3161 16.056 10.4835 16.3599 10.7872C16.6641 11.0916 16.8315 11.4958 16.8315 11.9257L16.8317 19.698Z"
          fill={`url(#${uid}paint0_linear_0_185)`}
        />
        <path
          id={`${uid}Vector_2`}
          d="M9.16406 13.7407C8.74987 13.7407 8.41406 14.0765 8.41406 14.4907V17.133C8.41406 17.5472 8.74987 17.883 9.16406 17.883C9.57825 17.883 9.91406 17.5472 9.91406 17.133V14.4907C9.91406 14.0765 9.57825 13.7407 9.16406 13.7407Z"
          fill={`url(#${uid}paint1_linear_0_185)`}
        />
      </g>
      <defs>
        <linearGradient
          id={`${uid}paint0_linear_0_185`}
          x1="1.34327"
          y1="3.22748"
          x2="17.7459"
          y2="3.83541"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#FF6464" />
          <stop offset="0.441262" stopColor="#F60101" />
          <stop offset="1" stopColor="#940202" />
        </linearGradient>
        <linearGradient
          id={`${uid}paint1_linear_0_185`}
          x1="8.52398"
          y1="14.3269"
          x2="9.8676"
          y2="14.3493"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#FF6464" />
          <stop offset="0.441262" stopColor="#F60101" />
          <stop offset="1" stopColor="#940202" />
        </linearGradient>
      </defs>
    </svg>
  );
}
