import type { SVGProps } from "react";

/** Figma: Design system → Icons → "plus" (24×24) */
export function IconPlus({ size, width, height, ...props }: SVGProps<SVGSVGElement> & { size?: number | string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={width ?? size ?? 24}
      height={height ?? size ?? 24}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      focusable="false"
      {...props}
    >
      <g id="plus-ic:outline-plus">
        <path
          id="plus-Vector"
          d="M18 12.3571C18 12.6333 17.7761 12.8571 17.5 12.8571H13.3571C13.081 12.8571 12.8571 13.081 12.8571 13.3571V17.5C12.8571 17.7761 12.6333 18 12.3571 18H11.6429C11.3667 18 11.1429 17.7761 11.1429 17.5V13.3571C11.1429 13.081 10.919 12.8571 10.6429 12.8571H6.5C6.22386 12.8571 6 12.6333 6 12.3571V11.6429C6 11.3667 6.22386 11.1429 6.5 11.1429H10.6429C10.919 11.1429 11.1429 10.919 11.1429 10.6429V6.5C11.1429 6.22386 11.3667 6 11.6429 6H12.3571C12.6333 6 12.8571 6.22386 12.8571 6.5V10.6429C12.8571 10.919 13.081 11.1429 13.3571 11.1429H17.5C17.7761 11.1429 18 11.3667 18 11.6429V12.3571Z"
          fill="white"
          fillOpacity="0.6"
        />
      </g>
    </svg>
  );
}
